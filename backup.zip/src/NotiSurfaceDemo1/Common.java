package NotiSurfaceDemo1;

public class Common {
    static final boolean DEBUG_CIRCLE = false;
}
