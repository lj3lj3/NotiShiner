/** Automatically generated file. DO NOT MODIFY */
package info.daylemk.notishiner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}